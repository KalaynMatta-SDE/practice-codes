import document1 from './document1';
import document2 from './document2';
import document3 from './document3';
import document4 from './document4';
import document5 from './document5';
import document6 from './document6';
import document7 from './document7';

const documents = {
  document1,
  document2,
  document3,
  document4,
  document5,
  document6,
  document7,
}

export default documents;
