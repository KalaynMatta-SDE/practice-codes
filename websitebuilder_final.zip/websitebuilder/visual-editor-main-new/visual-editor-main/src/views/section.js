const section = `
<section visual-editor="{{uuid}}">
{{{content}}}
</section>
`;

export default section;
