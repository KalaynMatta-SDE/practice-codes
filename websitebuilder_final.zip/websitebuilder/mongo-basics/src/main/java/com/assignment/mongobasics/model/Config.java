package com.assignment.mongobasics.model;

import lombok.Data;

@Data
public class Config {
    private int activeTab;
    private int previewMode;
}
